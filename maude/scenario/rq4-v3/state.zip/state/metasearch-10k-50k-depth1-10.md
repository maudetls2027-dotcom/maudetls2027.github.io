# RQ4-v3 10k-50k Depth 1-10 Status with Time

- Source: `maude/scenario/rq4-v3/state/metasearch-matrix*.jsonl`, excluding smoke.
- Records are keyed by JSON fields `(case, depth, k)`, not by filename.
- JSONL files scanned: 67
- Generated at: 2026-06-22T02:01:56+09:00
- Cell format for completed runs: `OK <visited_states> (<elapsed_sec>s)`.
- Failure cells include elapsed time when JSONL recorded it, e.g. `SIGKILL (522.4s)`.
- `INCOMPLETE` means raw `.maude` driver exists but no `.out`, `.err`, or JSONL result exists in this snapshot.
- `NO-RECORD` means no JSONL result and no raw files were found.

## cve-2022-25638

| Depth | 10k | 20k | 30k | 40k | 50k |
| --- | --- | --- | --- | --- | --- |
| 1 | OK 1,488 (153.4s) | OK 3,155 (246.2s) | OK 4,821 (341.3s) | OK 6,488 (446.8s) | OK 8,155 (514.5s) |
| 2 | OK 2,975 (177.0s) | OK 6,309 (327.4s) | OK 9,641 (525.3s) | OK 12,975 (736.1s) | OK 16,309 (995.5s) |
| 3 | OK 5,938 (202.5s) | OK 12,606 (404.7s) | OK 19,270 (685.6s) | OK 25,938 (1012.7s) | OK 32,606 (1453.9s) |
| 4 | OK 57,824 (216.0s) | OK 122,837 (493.2s) | OK 187,811 (888.7s) | OK 252,824 (1421.2s) | OK 317,837 (1994.6s) |
| 5 | OK 71,384 (886.7s) | OK 136,397 (3312.4s) | OK 201,371 (7136.9s) | SIGKILL (593.5s) | SIGKILL (595.6s) |
| 6 | OK 98,054 (1074.5s) | OK 163,067 (3583.3s) | OK 228,041 (7738.6s) | SIGKILL (586.6s) | SIGKILL (573.2s) |
| 7 | OK 124,764 (1421.9s) | OK 189,777 (4319.7s) | OK 254,751 (8706.4s) | SIGKILL (583.7s) | SIGKILL (569.8s) |
| 8 | OK 153,086 (1788.8s) | OK 218,099 (5000.9s) | SIGKILL (536.4s) | SIGKILL (538.0s) | SIGKILL (530.5s) |
| 9 | OK 191,766 (1796.7s) | OK 256,779 (5060.0s) | SIGKILL (528.5s) | SIGKILL (523.9s) | SIGKILL (522.4s) |
| 10 | OK 304,174 (2279.1s) | OK 369,187 (5883.3s) | SIGKILL (515.2s) | SIGKILL (522.7s) | SIGKILL (518.8s) |

## cve-2025-11934

| Depth | 10k | 20k | 30k | 40k | 50k |
| --- | --- | --- | --- | --- | --- |
| 1 | OK 1,488 (156.4s) | OK 3,155 (250.4s) | OK 4,821 (342.5s) | OK 6,488 (430.3s) | OK 8,155 (524.2s) |
| 2 | OK 2,975 (176.4s) | OK 6,309 (325.5s) | OK 9,641 (524.4s) | OK 12,975 (758.1s) | OK 16,309 (987.2s) |
| 3 | OK 5,938 (195.1s) | OK 12,606 (403.0s) | OK 19,270 (684.4s) | OK 25,938 (1018.7s) | OK 32,606 (1425.3s) |
| 4 | OK 57,824 (219.5s) | OK 122,837 (498.6s) | OK 187,811 (876.5s) | OK 252,824 (1428.5s) | OK 317,837 (1985.9s) |
| 5 | OK 71,384 (897.0s) | OK 136,397 (3283.0s) | OK 201,371 (7137.7s) | INCOMPLETE | INCOMPLETE |
| 6 | OK 98,054 (1078.4s) | OK 163,067 (3657.3s) | OK 228,041 (7762.0s) | INCOMPLETE | INCOMPLETE |
| 7 | OK 124,766 (1435.1s) | OK 189,779 (4243.3s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 8 | OK 153,170 (1765.3s) | OK 218,183 (5019.9s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 9 | OK 193,690 (1797.0s) | OK 258,703 (5021.6s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 10 | OK 311,294 (2326.1s) | OK 376,307 (5964.8s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |

## cve-2025-11935

| Depth | 10k | 20k | 30k | 40k | 50k |
| --- | --- | --- | --- | --- | --- |
| 1 | OK 1,488 (155.5s) | OK 3,155 (249.0s) | OK 4,821 (336.1s) | OK 6,488 (434.9s) | OK 8,155 (523.0s) |
| 2 | OK 2,975 (173.8s) | OK 6,309 (325.5s) | OK 9,641 (515.7s) | OK 12,975 (740.3s) | OK 16,309 (993.0s) |
| 3 | OK 5,938 (194.6s) | OK 12,606 (403.1s) | OK 19,270 (692.5s) | OK 25,938 (1027.4s) | OK 32,606 (1462.4s) |
| 4 | OK 57,824 (219.3s) | OK 122,837 (495.3s) | OK 187,811 (875.4s) | OK 252,824 (1385.3s) | OK 317,837 (1964.3s) |
| 5 | OK 71,384 (901.2s) | OK 136,397 (3309.7s) | OK 201,371 (7202.7s) | INCOMPLETE | INCOMPLETE |
| 6 | OK 98,054 (1075.3s) | OK 163,067 (3633.0s) | OK 228,041 (7568.2s) | INCOMPLETE | INCOMPLETE |
| 7 | OK 124,764 (1449.2s) | OK 189,777 (4307.4s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 8 | OK 153,086 (1820.1s) | OK 218,099 (4935.4s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 9 | OK 191,766 (1809.1s) | OK 256,779 (4977.8s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| 10 | OK 304,166 (2270.0s) | OK 369,179 (5922.6s) | INCOMPLETE | INCOMPLETE | INCOMPLETE |

## cve-2026-3230

| Depth | 10k | 20k | 30k | 40k | 50k |
| --- | --- | --- | --- | --- | --- |
| 1 | OK 1,489 (155.8s) | OK 3,156 (250.8s) | OK 4,822 (338.2s) | OK 6,489 (425.9s) | OK 8,156 (530.5s) |
| 2 | OK 2,977 (177.1s) | OK 6,311 (325.7s) | OK 9,643 (514.5s) | OK 12,977 (742.5s) | OK 16,311 (987.3s) |
| 3 | OK 5,931 (195.3s) | OK 12,598 (402.5s) | OK 19,263 (681.2s) | OK 25,931 (1026.0s) | OK 32,598 (1459.1s) |
| 4 | OK 6,112 (2995.8s) | OK 12,779 (3219.4s) | OK 19,444 (3702.8s) | OK 26,112 (4057.2s) | SIGKILL (611.2s) |
| 5 | OK 6,588 (215.2s) | OK 13,255 (497.5s) | OK 19,920 (918.3s) | OK 26,588 (1424.0s) | OK 33,255 (2046.2s) |
| 6 | OK 6,884 (219.6s) | OK 13,551 (502.1s) | OK 20,216 (913.7s) | OK 26,884 (1435.9s) | OK 33,551 (2088.8s) |
| 7 | OK 8,476 (224.9s) | OK 16,810 (509.2s) | OK 25,141 (924.9s) | OK 33,476 (1452.1s) | OK 41,810 (2102.7s) |
| 8 | OK 60,363 (246.6s) | OK 127,042 (595.9s) | OK 193,683 (1104.6s) | OK 260,363 (1783.4s) | OK 327,042 (2594.0s) |
| 9 | OK 73,993 (862.6s) | OK 140,672 (3077.1s) | OK 207,313 (6811.8s) | INCOMPLETE | INCOMPLETE |
| 10 | OK 100,733 (998.3s) | OK 167,412 (3383.7s) | OK 234,053 (7257.9s) | INCOMPLETE | INCOMPLETE |

